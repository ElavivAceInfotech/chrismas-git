<?php

namespace App\Models;
use Illuminate\Database\Eloquent\Model;

class Distcenter extends Model
{
    protected $guarded = [];
	public $table = "dist_center";
}
