<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class Roleuser extends Model
{
	protected $guarded = []; 
	public $table = "role_user";
}       