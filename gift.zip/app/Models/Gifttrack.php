<?php

namespace App\Models;
use Illuminate\Database\Eloquent\Model;

class Gifttrack extends Model
{
    protected $guarded = [];
	public $table = "gift_track";
}
